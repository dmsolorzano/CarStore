<?php
   define('host', 'earth.cs.utep.edu');   		//database server host
   define('username', 'asantellanes');   		//database username
   define('password', 'cs5339!asantellanes');    //database password
   define('database', 'asantellanes');   		//database name
   $db = mysqli_connect(host,username,password,database); //connection.

?>
