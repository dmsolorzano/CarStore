<?php
    include('session.php'); 
?>
<!DOCTYPE HTML>
<html>

<body>
<header id="top">
    <div class="inner"> <a href="umainpage.php" class="top">
        <ul>
      <li role="menu" class="active"><a href="user.php">User</a></li>
      <li role="menu"><a href="umainpage.php">Home</a></li>
      <li role="menu"><a href="logout.php">Logout</a></li>
    </ul>
    </div>
</header>
<h1>Home</h1>
</body>
</html>
