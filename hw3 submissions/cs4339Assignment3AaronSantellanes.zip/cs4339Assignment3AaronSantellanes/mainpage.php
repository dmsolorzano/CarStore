<!DOCTYPE HTML>
<html>
<body>

<header id="header">
    <div class="inner"><a href="mainpage.php" class="top">
      <ul class="navigation">
	    <li role="menu"><a href="mainpage.php">Home</a></li>
	    <li role="menu"><a href="login.php">Login</a></li>
	    <li role="menu"><a href="register.php">Sign-up</a></li>
      </ul>
    </div>
	<h1>Home</h1>
</header>
<a href="#menu" class="navigation"><span class="fa fa-bars"></span></a>

</body>
</html>
