<?php
    include('session.php'); 
?>

<!DOCTYPE HTML>
<html>
<body>
  <header id="header">
    <ul class="navigation">
      <li role="menu"><a href="admin.php">Admin</a></li>
	  <li role="menu"><a href="amainpage.php">Home</a></li>
	  <li role="menu"><a href="addUser.php">Add User</a></li>
	  <li role="menu"><a href="logout.php">Logout</a></li>
    </ul>
  </header>
  <h1>Home</h1>
</body>
</html>
